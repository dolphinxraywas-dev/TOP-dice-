# NBA DICE - Telegram Mini App

## 1. Firebase (free)
1. console.firebase.google.com > Add project.
2. Build > Firestore Database > Create database (production mode, any region).
3. Firestore > Rules: paste firestore.rules > Publish.
4. Build > Storage > Get started. Storage > Rules: paste storage.rules > Publish.
5. Project settings (gear) > Your apps > Web (</>) > register app > copy the firebaseConfig values into config.js.

## 2. GitHub Pages
1. Create a new public repo on github.com.
2. Upload index.html and config.js (Add file > Upload files).
3. Settings > Pages > Source: "Deploy from a branch" > main / root > Save.
4. Your link: https://YOUR-USER.github.io/YOUR-REPO/

## 3. Telegram
1. Open @BotFather > /newbot > follow the steps.
2. /mybots > your bot > Bot Settings > Menu Button > Configure menu button > send your GitHub Pages link.
   (Or /newapp to make a Mini App with a short link to share.)
3. Open your bot in Telegram and tap the menu button to play.

## Host
- Tap the dice icon at the top, passcode 1234 (host panel).
- In a group game, tap H, passcode 5678 (group control).
- Change both under Host Panel > Settings.
- Open the host panel first and add your account number and QR in Settings.

## Notes
- Passcodes and rules are simple and not secure enough for real money disputes. Keep stakes casual.
- Group rolls run from the host's phone: keep group control open until the round ends.
